import java.awt.*;
import java.awt.event.*;
public class FlowLayout {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Panel pa=new Panel();
		Frame f=new Frame("Flow Layout Example");
Button b=new Button();
Button b1=new Button();
Button b2=new Button();
Button b3=new Button();
f.add(pa);
pa.add(new Button("India"));
pa.add(new Button("china"));
pa.add(new Button ("pakistan"));
pa.add(new Button("Japan"));
pa.add(new Button ("Countries"));
f.setSize(400,400);
f.setVisible(true);
f.addWindowListener(new WindowAdapter()
		{
	public void windowClosing(WindowEvent we) {
		System.exit(0);
	}
		});
	}

}
